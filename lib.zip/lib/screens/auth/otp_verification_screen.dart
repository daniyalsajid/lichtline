import 'package:truckit/components/buttons/button_component.dart';
import 'package:truckit/components/text_component.dart';
import 'package:truckit/constants/colors/colors_constants.dart';
import 'package:truckit/constants/routes/routes_constants.dart';
import 'package:truckit/constants/strings/string_constants.dart';
import 'package:truckit/constants/styles/font_styles_constants.dart';
import 'package:flutter/material.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:truckit/ui_utils/size_config.dart';

class OTPVerificationScreen extends StatefulWidget {
  @override
  _OTPVerificationScreenState createState() => _OTPVerificationScreenState();
}

class _OTPVerificationScreenState extends State<OTPVerificationScreen> {
  TextEditingController _otpTextEditingController;
  @override
  void initState() {
    super.initState();
    _otpTextEditingController = new TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          width: SizeConfig.screenWidth,
          height: SizeConfig.screenHeight,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextComponent(
                text: StringConstant.truckIt,
                textStyle:
                    FontStyles.inter(color: ColorConstant.mango, fontSize: 38),
                textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 16,
              ),
              TextComponent(
                text: StringConstant.verifyOtpToCreateAnAccount,
                textStyle: FontStyles.inter(
                  color: ColorConstant.greyishBrownTwo,
                  fontWeight: FontWeight.w500,
                  fontSize: 16.0,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              TextComponent(
                text: StringConstant.afterVerificationYourAccountWillbeCreated,
                textStyle: FontStyles.inter(
                    color: ColorConstant.greyishBrownTwo,
                    fontSize: 12.0,
                    fontWeight: FontWeight.w400),
                textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 24,
              ),
              Row(
                children: [
                  SizedBox(
                    width: 30,
                  ),
                  Flexible(
                    child: PinCodeTextField(
                        appContext: context,
                        controller: _otpTextEditingController,
                        backgroundColor: Colors.transparent,
                        keyboardType: TextInputType.number,
                        pinTheme: PinTheme(
                            fieldHeight: 72,
                            fieldWidth: 65.8,
                            inactiveFillColor: ColorConstant.blueGreen,
                            selectedColor: ColorConstant.blueGreen,
                            selectedFillColor: ColorConstant.blueGreen,
                            activeFillColor: ColorConstant.blueGreen,
                            borderRadius: BorderRadius.circular(5),
                            borderWidth: 0.7,
                            activeColor: ColorConstant.blueGreen,
                            inactiveColor: ColorConstant.brownGrey,
                            shape: PinCodeFieldShape.box),
                        autoFocus: false,
                        animationCurve: Curves.easeIn,
                        cursorColor: ColorConstant.blueGreen,
                        length: 4,
                        onChanged: (value) {}),
                  ),
                  SizedBox(
                    width: 30,
                  ),
                ],
              ),
              SizedBox(
                height: 64,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: ButtonComponent(
                  onPressed: () => {
                    Navigator.pushNamed(context, RouteConstants.bottomBarScreen)
                  },
                  buttonText: StringConstant.verify,
                  border: 5,
                  textStyle: FontStyles.inter(
                      color: ColorConstant.white,
                      letterSpacing: 1.3,
                      fontWeight: FontWeight.w500,
                      fontSize: 16.0),
                ),
              ),
              SizedBox(
                height: 31,
              ),
              TextComponent(
                text: StringConstant.resendOTP,
                textStyle: FontStyles.inter(
                    color: ColorConstant.greyishBrownTwo,
                    letterSpacing: 1.3,
                    fontWeight: FontWeight.w500,
                    fontSize: 13.0),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
