import 'package:flutter_svg/svg.dart';
import 'package:truckit/components/buttons/button_component.dart';
import 'package:truckit/components/input_component.dart';
import 'package:truckit/components/text_component.dart';
import 'package:truckit/constants/assets/assets_constants.dart';
import 'package:truckit/constants/colors/colors_constants.dart';
import 'package:truckit/constants/routes/routes_constants.dart';
import 'package:truckit/constants/strings/string_constants.dart';
import 'package:truckit/constants/styles/font_styles_constants.dart';
import 'package:truckit/constants/styles/widgets_decoration_constant.dart';
import 'package:truckit/ui_utils/size_config.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  bool usePassword = false;
  TextEditingController _passwordTextEditingConrtroller;
  TextEditingController _phoneNumberTextEditingConrtroller;
  @override
  void initState() {
    super.initState();
    _passwordTextEditingConrtroller = new TextEditingController();
    _phoneNumberTextEditingConrtroller = new TextEditingController();
  }

  @override
  void dispose() {
    super.dispose();
    _passwordTextEditingConrtroller.dispose();
    _phoneNumberTextEditingConrtroller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      body: Container(
          width: SizeConfig.screenWidth,
          height: SizeConfig.screenHeight,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Spacer(),
                TextComponent(
                  text: StringConstant.truckIt,
                  textStyle: FontStyles.inter(
                      color: ColorConstant.mango, fontSize: 38),
                  textAlign: TextAlign.center,
                ),
                SizedBox(
                  height: 72,
                ),
                SizedBox(
                  height: 16,
                ),
                _textInputComponentLogin(userPassword: usePassword),
                SizedBox(
                  height: 24,
                ),
                ButtonComponent(
                  onPressed: () => {
                    setState(() {
                      if (usePassword) {
                        usePassword = false;
                      } else {
                        usePassword = true;
                      }
                    })
                  },
                  buttonText: StringConstant.usePassword,
                  color: ColorConstant.blueGreen,
                  border: 5,
                  textStyle: FontStyles.inter(
                      color: ColorConstant.white,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 1.3,
                      fontSize: 16.0),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 35.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Divider(
                          height: 0,
                          thickness: 0.3,
                          color: ColorConstant.greyishBrownTwo,
                        ),
                      ),
                      SizedBox(
                        width: 6,
                      ),
                      Text(
                        StringConstant.or.toUpperCase(),
                        style: FontStyles.inter(
                            color: ColorConstant.greyishBrownTwo,
                            fontSize: 14.0),
                      ),
                      SizedBox(
                        width: 6,
                      ),
                      Expanded(
                        child: Divider(
                          height: 0,
                          thickness: 0.3,
                          color: ColorConstant.greyishBrownTwo,
                        ),
                      ),
                    ],
                  ),
                ),
                ButtonComponent(
                  onPressed: () => {
                    Navigator.pushNamed(context, RouteConstants.otpVerification)
                  },
                  buttonText: StringConstant.useOTP,
                  color: ColorConstant.blueGreen,
                  border: 5,
                  textStyle: FontStyles.inter(
                      color: ColorConstant.white,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 1.3,
                      fontSize: 16.0),
                ),
                Image.asset(
                  AssetConstant.building_bg,
                  color: ColorConstant.brownGrey,
                ),
              ],
            ),
          )),
    );
  }

  TextInputComponent _textInputComponentLogin({bool userPassword = false}) {
    if (!userPassword) {
      return TextInputComponent(
        title: StringConstant.phoneNumber,
        controller: _phoneNumberTextEditingConrtroller,
        fillColor: ColorConstant.white,
        prefixIcon: Padding(
          padding: const EdgeInsets.only(top: 10, bottom: 10),
          child: SvgPicture.asset(
            AssetConstant.phone_icon,
            color: ColorConstant.mango,
          ),
        ),
        filled: true,
      );
    } else {
      return TextInputComponent(
        title: StringConstant.password,
        controller: _passwordTextEditingConrtroller,
        fillColor: ColorConstant.white,
        filled: true,
      );
    }
  }
}
