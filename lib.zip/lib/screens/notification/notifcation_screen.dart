import 'package:flutter_svg/svg.dart';
import 'package:truckit/components/app_bars/simple_app_bar_component.dart';
import 'package:truckit/components/text_component.dart';
import 'package:truckit/constants/assets/assets_constants.dart';
import 'package:truckit/constants/colors/colors_constants.dart';
import 'package:truckit/constants/routes/routes_constants.dart';
import 'package:truckit/constants/strings/string_constants.dart';
import 'package:flutter/material.dart';
import 'package:truckit/constants/styles/font_styles_constants.dart';
import 'package:truckit/ui_utils/size_config.dart';

class NotificationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      appBar: SimpleAppBarComponent(
        isBackButton: true,
        color: ColorConstant.white,
        height: kToolbarHeight,
        isTitle: true,
        centerTitle: true,
        title: StringConstant.notifications,
        titleStyle: FontStyles.inter(
            color: ColorConstant.greyishBrownThree,
            fontSize: 14,
            fontWeight: FontWeight.w500),
      ),
      body: Container(
        height: SizeConfig.screenHeight,
        width: SizeConfig.screenWidth,
        color: ColorConstant.whiteBody,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: ListView.builder(
                  itemCount: 14,
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () {
                        Navigator.pushNamed(context, RouteConstants.chat);
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 16.0, right: 16.0, top: 10),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            decoration: new BoxDecoration(
                              color: ColorConstant.white,
                              border: Border(
                                left: BorderSide(
                                    width: index == 1 ? 5 : 0,
                                    color: ColorConstant.mango),
                              ),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    flex: 6,
                                    child: Row(
                                      children: [
                                        Container(
                                          height: 48,
                                          width: 48,
                                          padding: EdgeInsets.all(10),
                                          decoration: new BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: ColorConstant.mango
                                                .withOpacity(0.3),
                                          ),
                                          child: ClipOval(
                                            child: SvgPicture.asset(
                                              AssetConstant.end_point_icon,
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 6,
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                TextComponent(
                                                  text: "Truck is on the way",
                                                  textStyle: FontStyles.inter(
                                                      color: ColorConstant
                                                          .greyishBrownTwo,
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.w500),
                                                ),
                                                SizedBox(
                                                  height: 6,
                                                ),
                                                TextComponent(
                                                  text:
                                                      "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
                                                  textStyle: FontStyles.inter(
                                                      color: ColorConstant
                                                          .greyishBrownTwo,
                                                      fontSize: 12,
                                                      fontWeight:
                                                          FontWeight.w400),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Align(
                                        alignment: Alignment.topRight,
                                        child: index == 1
                                            ? Container(
                                                height: 10,
                                                width: 10,
                                                decoration: new BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    color: ColorConstant.mango),
                                              )
                                            : null,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
            )
          ],
        ),
      ),
    );
  }
}
