import 'package:truckit/components/app_bars/simple_app_bar_component.dart';
import 'package:truckit/components/container_card_component.dart';
import 'package:truckit/components/filter_chips_component.dart';
import 'package:truckit/components/stepper_card_component/custom_card_list_tile_component.dart';
import 'package:truckit/components/stepper_card_component/stepper_card_component.dart';
import 'package:truckit/components/stepper_card_component/title_and_subtitle_component.dart';
import 'package:truckit/constants/assets/assets_constants.dart';
import 'package:truckit/constants/colors/colors_constants.dart';
import 'package:truckit/constants/routes/routes_constants.dart';
import 'package:truckit/constants/strings/string_constants.dart';
import 'package:truckit/ui_utils/size_config.dart';
import 'package:flutter/material.dart';

class RidesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      appBar: SimpleAppBarComponent(
        isBackButton: false,
        isTrailingIcon: true,
        color: ColorConstant.whiteBody,
        imageTitle: AssetConstant.delivery_truck,
        isImageTitle: true,
        isTitle: true,
        title: StringConstant.truckIt,
        onTapTrailingIcon: () =>
            Navigator.pushNamed(context, RouteConstants.notification),
      ),
      body: Container(
        height: SizeConfig.screenHeight,
        width: SizeConfig.screenWidth,
        color: ColorConstant.whiteBody,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AspectRatio(
                aspectRatio: 2 / 0.2,
                child: ListView.builder(
                  itemCount: 3,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4.0),
                      child: FilterChipsComponent(
                        label: "Current Rides",
                        selected: true,
                        onSelected: (value) => {},
                      ),
                    );
                  },
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: 3,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: ContainerCard(
                        child: CustomStepperCard(
                          dateFrom: "Thursday, April 3, 2020 - 6:00 AM",
                          addressFrom: "Central Warehouse, Mauripur, Karachi",
                          dateTo: "Thursday, April 3, 2020 - 6:00 AM",
                          addressTo:
                              "Central Warehouse, Mauripur, Karachi Central Warehouse, Mauripur, Karachi",
                          childWidgets: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    top: 8.0, left: 40, right: 10, bottom: 10),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    TitleAndSubTitleComponent(
                                      title: StringConstant.totalAmount,
                                      subTitle: "27,000 PKR",
                                    ),
                                    TitleAndSubTitleComponent(
                                      title: StringConstant.totalDistance,
                                      subTitle: "424 KMs",
                                    ),
                                    TitleAndSubTitleComponent(
                                      title: StringConstant.totalCovered,
                                      subTitle: "853 KMs",
                                    )
                                  ],
                                ),
                              ),
                              Divider(
                                thickness: 0.8,
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 15.0, vertical: 10),
                                child: CustomCardListTileComponent(
                                  image:
                                      "https://cdn.cnn.com/cnnnext/dam/assets/150723122647-india-truck-art-front-jodhpur-full-169.jpg",
                                  title: "Truck Assigned".toUpperCase(),
                                  subTitle_1: "LSB - 7133".toUpperCase(),
                                  subTitle_2: "Mazda, 16 ft Flatbed",
                                  rideStatus: "on trip",
                                  btnHorizontalPadding: 25,
                                  onTap: () => Navigator.pushNamed(context,
                                      RouteConstants.currentRideScreen),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
