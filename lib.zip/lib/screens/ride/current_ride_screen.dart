import 'package:flutter/gestures.dart';
import 'package:truckit/components/app_bars/simple_app_bar_component.dart';
import 'package:truckit/components/buttons/custom_container_button_component.dart';
import 'package:truckit/components/container_card_component.dart';
import 'package:truckit/components/stepper_card_component/custom_card_list_tile_component.dart';
import 'package:truckit/components/stepper_card_component/stepper_card_component.dart';
import 'package:truckit/components/stepper_card_component/title_and_subtitle_component.dart';
import 'package:truckit/components/text_component.dart';
import 'package:truckit/constants/colors/colors_constants.dart';
import 'package:truckit/constants/routes/routes_constants.dart';
import 'package:truckit/constants/strings/string_constants.dart';
import 'package:flutter/material.dart';
import 'package:truckit/constants/styles/font_styles_constants.dart';
import 'package:truckit/ui_utils/size_config.dart';

var currentScreenContext;

class CurrentRideScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    currentScreenContext = context;
    SizeConfig().init(context);
    return Scaffold(
      appBar: SimpleAppBarComponent(
        isBackButton: true,
        color: ColorConstant.white,
        height: kToolbarHeight,
        isTitle: true,
        centerTitle: true,
        title: "Engro Corp - LO10909201",
        titleStyle: FontStyles.inter(
            color: ColorConstant.greyishBrownThree,
            fontSize: 14,
            fontWeight: FontWeight.w500),
      ),
      body: Container(
        height: SizeConfig.screenHeight,
        width: SizeConfig.screenWidth,
        color: ColorConstant.whiteBody,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _bidInfoCard(),
              _customCardWithTitleAndSubtitleInColumn(
                title: StringConstant.dateAndTime,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    multiTitleAndSubTitleColumn(
                        title_1: StringConstant.pickupDate.toUpperCase(),
                        title_2: StringConstant.dropOfDate.toUpperCase(),
                        subTitle_1: "April 20, 2020",
                        subTitle_2: "April 20, 2020"),
                    multiTitleAndSubTitleColumn(
                        title_1: StringConstant.pickupTime.toUpperCase(),
                        title_2: StringConstant.dropOfTime.toUpperCase(),
                        subTitle_1: "6:30 PM",
                        subTitle_2: "6:30 PM"),
                    multiTitleAndSubTitleColumn(
                        title_1: StringConstant.distance.toUpperCase(),
                        title_2: StringConstant.weightVolume.toUpperCase(),
                        subTitle_1: "12,000 KMs",
                        subTitle_2: "1,000 Kg"),
                  ],
                ),
              ),
              _customCardWithTitleAndSubtitleInColumn(
                title: StringConstant.loadDetails,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    multiTitleAndSubTitleColumn(
                        title_1: StringConstant.quantity.toUpperCase(),
                        title_2: StringConstant.loadingDuration.toUpperCase(),
                        subTitle_1: "20 Bags",
                        subTitle_2: "3 Hours"),
                    multiTitleAndSubTitleColumn(
                        title_1: StringConstant.commodity.toUpperCase(),
                        title_2: StringConstant.loadingTime.toUpperCase(),
                        subTitle_1: "Powder",
                        subTitle_2: "6:00 PM"),
                    multiTitleAndSubTitleColumn(
                        title_1: StringConstant.value.toUpperCase(),
                        title_2: StringConstant.serialNumber.toUpperCase(),
                        subTitle_1: "10,000",
                        subTitle_2: "B-34895"),
                  ],
                ),
              ),
              _customCardWithTitleAndSubtitleInColumn(
                title: StringConstant.contactPersonDropOff,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    multiTitleAndSubTitleColumn(
                        title_1: StringConstant.name.toUpperCase(),
                        subTitle_1: "Osama Asif",
                        secondRow: false),
                    multiTitleAndSubTitleColumn(
                        title_1: StringConstant.phoneNumber.toUpperCase(),
                        subTitle_1: "+92 312 8280628,\n+92 312 8280628",
                        secondRow: false),
                    SizedBox()
                  ],
                ),
              ),
              _consignmentLoadingImages(),
              _customCardWithTitleAndSubtitleInColumn(
                title: "Fleet Owner Details",
                child: CustomCardListTileComponent(
                  image:
                      "https://cdn.cnn.com/cnnnext/dam/assets/150723122647-india-truck-art-front-jodhpur-full-169.jpg",
                  title: "Company".toUpperCase(),
                  subTitle_1: "Afraid Transports".toUpperCase(),
                  subTitle_2: "+92 333 1234567",
                  isTrailingBtn: false,
                  isReviewStar: true,
                  reviewStar: 5,
                ),
              ),
              _customCardWithTitleAndSubtitleInColumn(
                title: "Truck Assigned".toUpperCase(),
                child: CustomCardListTileComponent(
                  image:
                      "https://cdn.cnn.com/cnnnext/dam/assets/150723122647-india-truck-art-front-jodhpur-full-169.jpg",
                  title: "Details".toUpperCase(),
                  subTitle_1: "LSB - 7133".toUpperCase(),
                  subTitle_2: "Mazda, 16 ft Flatbed ",
                  isTrailingBtn: false,
                ),
              ),
              SizedBox(
                height: 20,
              )
            ],
          ),
        ),
      ),
    );
  }

  Column _consignmentLoadingImages() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextComponent(
            text: "Consignment Images At On - Loading".toUpperCase(),
            textStyle: FontStyles.inter(
                color: ColorConstant.greyishBrownTwo,
                fontSize: 13,
                fontWeight: FontWeight.w300),
          ),
        ),
        SizedBox(
          height: 150,
          child: Padding(
            padding: const EdgeInsets.only(top: 8.0, bottom: 8.0, left: 8.0),
            child: ListView.builder(
              itemCount: 5,
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index) {
                return Padding(
                  padding: EdgeInsets.only(right: 8.0),
                  child: SizedBox(
                    height: 128,
                    width: 128,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        "https://www.mmh.com/images/top20warehouse1218.jpg",
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        )
      ],
    );
  }

  Padding _customCardWithTitleAndSubtitleInColumn(
      {@required String title, @required Widget child}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 6),
      child: ContainerCard(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              TextComponent(
                text: title.toUpperCase(),
                textStyle: FontStyles.inter(
                    color: ColorConstant.greyishBrownTwo,
                    fontSize: 13,
                    fontWeight: FontWeight.w300),
              ),
              SizedBox(
                height: 20,
              ),
              child,
            ],
          ),
        ),
      ),
    );
  }

  Column multiTitleAndSubTitleColumn(
      {@required String title_1,
      @required String subTitle_1,
      String title_2,
      String subTitle_2 = "",
      bool secondRow = true}) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TitleAndSubTitleComponent(
          title: title_1,
          subTitle: subTitle_1,
        ),
        secondRow
            ? SizedBox(
                height: 24,
              )
            : SizedBox(),
        secondRow
            ? TitleAndSubTitleComponent(
                title: title_2,
                subTitle: subTitle_2,
              )
            : SizedBox()
      ],
    );
  }

  Padding _bidInfoCard() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: ContainerCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding:
                  const EdgeInsets.symmetric(vertical: 16.0, horizontal: 16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextComponent(
                    text: "Bid ID: LO10909201 ",
                    textStyle: FontStyles.inter(
                        color: ColorConstant.greyishBrownTwo,
                        fontSize: 13,
                        fontWeight: FontWeight.w700),
                  ),
                  CustomContainerButtonComponent(
                    text: StringConstant.reportAProblem,
                    horizontal: 12,
                    onTap: () => {
                      Navigator.pushNamed(
                          currentScreenContext, RouteConstants.reportNow)
                    },
                    color: ColorConstant.mango,
                    textColor: ColorConstant.white,
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextComponent(
                    text: "Bid ID: LO10909201 ",
                    textStyle: FontStyles.inter(
                        color: ColorConstant.brownGrey,
                        fontSize: 10,
                        fontWeight: FontWeight.w700),
                  ),
                  SizedBox(
                    height: 6,
                  ),
                  TextComponent(
                    text: "April 20, 2020",
                    textStyle: FontStyles.inter(
                        color: ColorConstant.greyishBrownTwo,
                        fontSize: 13,
                        fontWeight: FontWeight.w700),
                  ),
                  SizedBox(
                    height: 16,
                  ),
                  RichText(
                    text: TextSpan(
                      text: 'Trip Status:',
                      style: FontStyles.inter(
                          color: ColorConstant.greyishBrownTwo,
                          fontSize: 13,
                          fontWeight: FontWeight.w500),
                      children: <TextSpan>[
                        TextSpan(
                            text: ' On Trip',
                            style: FontStyles.inter(
                                color: ColorConstant.blueGreen,
                                fontSize: 13,
                                fontWeight: FontWeight.w700),
                            recognizer: TapGestureRecognizer()
                              ..onTap = () {
                                // navigate to desired screen
                              })
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: CustomStepperCard(
                dateFrom: "Thursday, April 3, 2020 - 6:00 AM",
                addressFrom: "Central Warehouse, Mauripur, Karachi",
                dateTo: "Thursday, April 3, 2020 - 6:00 AM",
                addressTo:
                    "Central Warehouse, Mauripur, Karachi Central Warehouse, Mauripur, Karachi",
                trailingIcons: false,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
