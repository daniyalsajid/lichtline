import 'package:truckit/components/app_bars/simple_app_bar_component.dart';
import 'package:truckit/components/buttons/custom_container_button_component.dart';
import 'package:truckit/components/container_card_component.dart';
import 'package:truckit/components/stepper_card_component/custom_card_list_tile_component.dart';
import 'package:truckit/components/stepper_card_component/stepper_card_component.dart';
import 'package:truckit/components/stepper_card_component/title_and_subtitle_component.dart';
import 'package:truckit/components/tab_bar_component.dart';
import 'package:truckit/constants/assets/assets_constants.dart';
import 'package:truckit/constants/colors/colors_constants.dart';
import 'package:truckit/constants/routes/routes_constants.dart';
import 'package:truckit/constants/strings/string_constants.dart';
import 'package:truckit/ui_utils/size_config.dart';
import 'package:flutter/material.dart';

class BidsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      appBar: SimpleAppBarComponent(
          isBackButton: false,
          isTrailingIcon: true,
          color: ColorConstant.whiteBody,
          imageTitle: AssetConstant.delivery_truck,
          isImageTitle: true,
          isTitle: true,
          title: StringConstant.truckIt,
          onTapTrailingIcon: () =>
              Navigator.pushNamed(context, RouteConstants.notification)),
      body: Container(
        height: SizeConfig.screenHeight,
        width: SizeConfig.screenWidth,
        color: ColorConstant.whiteBody,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8.0),
          child: DefaultTabController(
            initialIndex: 0,
            length: 2,
            child: Column(
              children: [
                Expanded(
                  child: TabBarViewComponent(
                    childrenTabs: [
                      _tabsBodyAllBids(),
                      _tabsBodyAcceptedBids(),
                    ],
                    tabsName: [
                      StringConstant.allBids,
                      StringConstant.acceptedBids,
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  ListView _tabsBodyAllBids() {
    return ListView.builder(
      itemCount: 3,
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.all(4.0),
          child: ContainerCard(
            child: CustomStepperCard(
              dateFrom: "Thursday, April 3, 2020 - 6:00 AM",
              addressFrom: "Central Warehouse, Mauripur, Karachi",
              dateTo: "Thursday, April 3, 2020 - 6:00 AM",
              addressTo:
                  "Central Warehouse, Mauripur, Karachi Central Warehouse, Mauripur, Karachi",
              showOnlyChatTrailingIcon: true,
              childWidgets: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                        top: 8.0, left: 40, right: 10, bottom: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TitleAndSubTitleComponent(
                          title: StringConstant.averageBid,
                          subTitle: "27,000 PKR",
                        ),
                        TitleAndSubTitleComponent(
                          title: StringConstant.totalBids,
                          subTitle: "40",
                        ),
                        TitleAndSubTitleComponent(
                          title: StringConstant.totalViews,
                          subTitle: "128",
                        )
                      ],
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CustomContainerButtonComponent(
                        text: StringConstant.viewDetails,
                        textColor: ColorConstant.white,
                        color: ColorConstant.blueGreen,
                        horizontal: 10,
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  ListView _tabsBodyAcceptedBids() {
    return ListView.builder(
      itemCount: 3,
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.all(4.0),
          child: ContainerCard(
            child: CustomStepperCard(
              dateFrom: "Thursday, April 3, 2020 - 6:00 AM",
              addressFrom: "Central Warehouse, Mauripur, Karachi",
              dateTo: "Thursday, April 3, 2020 - 6:00 AM",
              addressTo:
                  "Central Warehouse, Mauripur, Karachi Central Warehouse, Mauripur, Karachi",
              showOnlyChatTrailingIcon: true,
              childWidgets: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                        top: 8.0, left: 40, right: 10, bottom: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TitleAndSubTitleComponent(
                          title: StringConstant.totalAmount,
                          subTitle: "27,000 PKR",
                        ),
                        TitleAndSubTitleComponent(
                          title: StringConstant.totalDistance,
                          subTitle: "424 KMs",
                        ),
                        TitleAndSubTitleComponent(
                          title: StringConstant.totalCovered,
                          subTitle: "853 KMs",
                        )
                      ],
                    ),
                  ),
                  Column(
                    children: [
                      Divider(
                        thickness: 0.8,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 15.0, vertical: 10),
                        child: CustomCardListTileComponent(
                          image:
                              "https://cdn.cnn.com/cnnnext/dam/assets/150723122647-india-truck-art-front-jodhpur-full-169.jpg",
                          title: "Company".toUpperCase(),
                          subTitle_1: "Afraid Transports".toUpperCase(),
                          rideStatus: StringConstant.verifyPayment,
                          showStarInsteadSubTitle: true,
                          showVerifiedBage: true,
                          reviewStar: 5,
                          isReviewStar: true,
                          btnColor: ColorConstant.blueGreen,
                          btnTitleColor: ColorConstant.white,
                          btnHorizontalPadding: 8,
                          onTap: () => Navigator.pushNamed(
                              context, RouteConstants.paymentVerification),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
