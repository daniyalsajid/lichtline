import 'dart:io';

import 'package:flutter_svg/svg.dart';
import 'package:truckit/components/app_bars/simple_app_bar_component.dart';
import 'package:truckit/components/add_image_placeholder_component.dart';
import 'package:truckit/components/image_placeholder_component.dart';
import 'package:truckit/components/text_component.dart';
import 'package:truckit/constants/assets/assets_constants.dart';
import 'package:truckit/constants/colors/colors_constants.dart';
import 'package:truckit/constants/strings/string_constants.dart';
import 'package:flutter/material.dart';
import 'package:truckit/constants/styles/font_styles_constants.dart';
import 'package:truckit/ui_utils/size_config.dart';
import 'package:truckit/ui_utils/snackbar.dart';
import 'package:truckit/utils/file_picker_utils.dart';

class PaymentVerificationScreen extends StatefulWidget {
  @override
  _PaymentVerificationScreenState createState() =>
      _PaymentVerificationScreenState();
}

class _PaymentVerificationScreenState extends State<PaymentVerificationScreen> {
  GlobalKey<ScaffoldState> _scaffoldKey;
  List<File> _fileList = [];
  @override
  void initState() {
    super.initState();
    _scaffoldKey = new GlobalKey<ScaffoldState>();
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      key: _scaffoldKey,
      appBar: SimpleAppBarComponent(
        isBackButton: true,
        color: ColorConstant.white,
        height: kToolbarHeight,
        isTitle: true,
        centerTitle: true,
        title: StringConstant.paymentVerification,
        titleStyle: FontStyles.inter(
            color: ColorConstant.greyishBrownThree,
            fontSize: 14,
            fontWeight: FontWeight.w500),
      ),
      body: Container(
        height: SizeConfig.screenHeight,
        width: SizeConfig.screenWidth,
        color: ColorConstant.whiteBody,
        child: SingleChildScrollView(
          child: Container(
            height: SizeConfig.screenHeight,
            width: SizeConfig.screenWidth,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _headerRowWithCopyCode(),
                  SizedBox(
                    height: 12,
                  ),
                  TextComponent(
                    text: "TIP938227123960",
                    textStyle: FontStyles.inter(
                        color: ColorConstant.greyishBrownTwo,
                        fontSize: 20,
                        fontWeight: FontWeight.w400),
                  ),
                  SizedBox(
                    height: 24,
                  ),
                  TextComponent(
                    text: StringConstant.uploadReceiptImage,
                    textStyle: FontStyles.inter(
                        color: ColorConstant.greyishBrownTwo,
                        fontSize: 13,
                        fontWeight: FontWeight.w300),
                  ),
                  SizedBox(
                    height: 24,
                  ),
                  Wrap(
                    alignment: WrapAlignment.center,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      ImagePlaceHolderComponent(
                        placeHolder: _fileList,
                        onTapRemove: _onRemoveImage,
                      ),
                      SizedBox(
                        width: 4,
                      ),
                      AddImagePlaceHolderComponent(
                        placeHolderLength: 4 - _fileList.length,
                        onTap: _selectImage,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  _onRemoveImage(int imageIndex) {
    setState(() {
      _fileList.removeAt(imageIndex);
    });
  }

  _selectImage() async {
    List<File> _file = await FilePickerUtils().pickFile();
    if (_file.length > 4) {
      for (var i = 0; i < _file.length; i++) {
        if (_file.length > 4) {
          _file.removeLast();
        }
      }
      SnackbarUtils.showInSnackBar(
          "Maximum attachment limit is 4", _scaffoldKey);
    }
    setState(() {
      _fileList = [..._fileList, ..._file];
    });
  }

  Row _headerRowWithCopyCode() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        TextComponent(
          text: StringConstant.easyPaisaToken,
          textStyle: FontStyles.inter(
              color: ColorConstant.greyishBrownTwo,
              fontSize: 14,
              fontWeight: FontWeight.w300),
        ),
        Wrap(
          crossAxisAlignment: WrapCrossAlignment.center,
          alignment: WrapAlignment.center,
          children: [
            SvgPicture.asset(
              AssetConstant.copy_code_icon,
              width: 15,
              height: 15,
            ),
            TextComponent(
              text: StringConstant.copyCode,
              textStyle: FontStyles.inter(
                  color: ColorConstant.greyishBrownTwo,
                  fontSize: 13,
                  fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ],
    );
  }
}
