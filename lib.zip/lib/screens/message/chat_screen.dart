import 'package:truckit/components/app_bars/simple_app_bar_component.dart';
import 'package:truckit/components/text_component.dart';
import 'package:truckit/constants/assets/assets_constants.dart';
import 'package:truckit/constants/colors/colors_constants.dart';
import 'package:flutter/material.dart';
import 'package:truckit/constants/strings/string_constants.dart';
import 'package:truckit/constants/styles/font_styles_constants.dart';
import 'package:truckit/ui_utils/size_config.dart';

class ChatScreen extends StatefulWidget {
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  TextEditingController _chatEditingController;
  @override
  void initState() {
    super.initState();
    _chatEditingController = new TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      appBar: SimpleAppBarComponent(
        height: 52,
        isBackButton: true,
        isTrailingIcon: true,
        color: ColorConstant.whiteBody,
        isTitle: true,
        title: "Bidder: Engro Corp - LO10909201",
        subTitle: "• Online Now",
        isSubTitle: true,
        centerTitle: true,
        titleStyle: FontStyles.inter(
            color: ColorConstant.greyishBrownTwo, fontSize: 14),
        subTitleStyle: FontStyles.inter(
            color: ColorConstant.blueGreen,
            fontSize: 10,
            fontWeight: FontWeight.w500),
        trailingIconName: AssetConstant.menu_dots_icon,
      ),
      body: Container(
        height: SizeConfig.screenHeight,
        width: SizeConfig.screenWidth,
        color: ColorConstant.whiteBody,
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: 2,
                itemBuilder: (context, index) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _messageFrom(),
                      _messageTo(),
                    ],
                  );
                },
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Flexible(
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 16.0, right: 8.0, bottom: 20, top: 2),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(50),
                        child: Scrollbar(
                          radius: Radius.circular(50),
                          child: TextFormField(
                            controller: _chatEditingController,
                            minLines: 1,
                            maxLines: 8,
                            scrollPadding:
                                EdgeInsets.only(right: 20.0, left: 10),
                            keyboardType: TextInputType.text,
                            decoration: InputDecoration(
                              hintText: StringConstant.typeYourMessage,
                              fillColor: ColorConstant.white,
                              filled: true,
                              suffixIcon: _chatEditingController.text == ""
                                  ? _suffixIcons()
                                  : null,
                              hintStyle: FontStyles.inter(
                                  color: ColorConstant.greyishBrownTwo),
                              border: InputBorder.none,
                            ),
                            cursorColor: ColorConstant.blueGreen,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(right: 16.0, bottom: 25),
                    child: _circularIcons(
                      () => {},
                      AssetConstant.send_icon,
                      icon: Icon(
                        Icons.send_sharp,
                        color: ColorConstant.white,
                      ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Wrap _suffixIcons() {
    return Wrap(
      runAlignment: WrapAlignment.center,
      children: [
        _circularIcons(() => {}, AssetConstant.camera_icon,
            icon: Icon(
              Icons.camera_alt,
              color: ColorConstant.white,
            )),
        _circularIcons(() => {}, AssetConstant.mic_icon,
            icon: Icon(
              Icons.mic,
              color: ColorConstant.white,
            ))
      ],
    );
  }

  Padding _circularIcons(void Function() onTap, String iconName,
      {Widget icon}) {
    return Padding(
      padding: const EdgeInsets.only(right: 8.0),
      child: InkWell(
        enableFeedback: true,
        onTap: onTap,
        child: Container(
          decoration: new BoxDecoration(
              color: ColorConstant.blueGreen, shape: BoxShape.circle),
          child: Padding(
            padding: const EdgeInsets.all(6.0),
            child: icon,
            // SvgPicture.asset(
            //   iconName,
            //   color: ColorConstant.white,
            // ),
          ),
        ),
      ),
    );
  }

  Padding _messageTo() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 15),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          _chatTextContainer(
              messageTime: "17:45",
              messageText:
                  "I’m going to San Francisco and I’m booking an Airbnb. Would you like to come?",
              borderRadiusBottomRight: 0,
              containerColor: ColorConstant.white,
              textColor: ColorConstant.greyishBrownTwo),
          SizedBox(
            width: 10,
          ),
          userImage(
            imageUrl:
                "https://data.whicdn.com/images/302934819/original.jpg?t=1513612958",
          ),
        ],
      ),
    );
  }

  Padding _messageFrom() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 15),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          userImage(
              imageUrl:
                  "https://data.whicdn.com/images/302934819/original.jpg?t=1513612958"),
          SizedBox(
            width: 10,
          ),
          _chatTextContainer(
              messageTime: "17:45",
              messageText:
                  "I’m going to San Francisco and I’m booking an Airbnb. Would you like to come?",
              borderRadiusBottomLeft: 0)
        ],
      ),
    );
  }

  SizedBox userImage({@required String imageUrl}) {
    return SizedBox(
      height: 32,
      width: 32,
      child: ClipOval(
        child: Image.network(
          imageUrl,
          fit: BoxFit.cover,
        ),
      ),
    );
  }

  Flexible _chatTextContainer(
      {double borderRadiusTopLeft = 25,
      double borderRadiusTopRight = 25,
      double borderRadiusBottomLeft = 25,
      double borderRadiusBottomRight = 25,
      String messageText = "",
      String messageTime = "",
      Color containerColor = ColorConstant.blueGreen,
      Color textColor = ColorConstant.white}) {
    return Flexible(
      child: Container(
        decoration: new BoxDecoration(
          color: containerColor,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(borderRadiusTopLeft),
            topRight: Radius.circular(borderRadiusTopRight),
            bottomRight: Radius.circular(borderRadiusBottomRight),
            bottomLeft: Radius.circular(borderRadiusBottomLeft),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextComponent(
                text: messageText,
                textStyle: FontStyles.inter(
                    color: textColor,
                    fontSize: 13,
                    letterSpacing: 0.4,
                    height: 1.3,
                    fontWeight: FontWeight.w400),
              ),
              SizedBox(
                height: 10,
              ),
              TextComponent(
                text: messageTime,
                textStyle: FontStyles.inter(
                    color: textColor,
                    fontSize: 13,
                    fontWeight: FontWeight.w400),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
