import 'package:truckit/components/app_bars/simple_app_bar_component.dart';
import 'package:truckit/components/buttons/button_component.dart';
import 'package:truckit/components/input_component.dart';
import 'package:truckit/components/review_star_component.dart';
import 'package:truckit/components/text_component.dart';
import 'package:truckit/constants/colors/colors_constants.dart';
import 'package:truckit/constants/strings/string_constants.dart';
import 'package:flutter/material.dart';
import 'package:truckit/constants/styles/font_styles_constants.dart';
import 'package:truckit/ui_utils/size_config.dart';

class RateNowScreen extends StatefulWidget {
  @override
  _RateNowScreenState createState() => _RateNowScreenState();
}

class _RateNowScreenState extends State<RateNowScreen> {
  int ratedStarCount = 1;
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      appBar: SimpleAppBarComponent(
        isBackButton: true,
        color: ColorConstant.white,
        height: kToolbarHeight,
        isTitle: true,
        centerTitle: true,
        title: StringConstant.rateNow,
        titleStyle: FontStyles.inter(
            color: ColorConstant.greyishBrownThree,
            fontSize: 14,
            fontWeight: FontWeight.w500),
      ),
      body: Container(
        height: SizeConfig.screenHeight,
        width: SizeConfig.screenWidth,
        color: ColorConstant.whiteBody,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _title(StringConstant.rateyourTrip),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: ReviewStars(
                starCount: 5,
                starSize: 35,
                paddingRight: 10,
                ratedStar: ratedStarCount,
                isRateReview: true,
                onTapForRatingStar: starRating,
              ),
            ),
            _title(StringConstant.writeYourReview),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextInputComponent(
                title: StringConstant.writeReviewHere,
                fillColor: ColorConstant.white,
                keyboardType: TextInputType.multiline,
                minLines: 4,
                maxLines: 8,
                filled: true,
              ),
            ),
            Expanded(
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ButtonComponent(
                    buttonText: StringConstant.reportNow,
                    border: 5,
                    textStyle: FontStyles.inter(
                        color: ColorConstant.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w500),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Padding _title(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0, top: 12, left: 15, right: 15),
      child: TextComponent(
        text: title.toUpperCase(),
        textStyle: FontStyles.inter(
            color: ColorConstant.greyishBrownTwo,
            fontSize: 13,
            fontWeight: FontWeight.w400),
      ),
    );
  }

  starRating(int selectedStarCount) {
    setState(() {
      ratedStarCount = selectedStarCount;
    });
  }
}
