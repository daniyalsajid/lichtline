import 'package:truckit/components/app_bars/simple_app_bar_component.dart';
import 'package:truckit/components/buttons/custom_container_button_component.dart';
import 'package:truckit/components/container_card_component.dart';
import 'package:truckit/components/stepper_card_component/stepper_card_component.dart';
import 'package:truckit/components/text_component.dart';
import 'package:truckit/constants/colors/colors_constants.dart';
import 'package:truckit/constants/routes/routes_constants.dart';
import 'package:truckit/constants/strings/string_constants.dart';
import 'package:truckit/constants/styles/font_styles_constants.dart';
import 'package:truckit/ui_utils/size_config.dart';
import 'package:flutter/material.dart';

class ReviewScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      appBar: SimpleAppBarComponent(
        isBackButton: true,
        color: ColorConstant.white,
        height: kToolbarHeight,
        isTitle: true,
        centerTitle: true,
        title: StringConstant.reviews,
        titleStyle: FontStyles.inter(
            color: ColorConstant.greyishBrownThree,
            fontSize: 14,
            fontWeight: FontWeight.w500),
      ),
      body: Container(
        height: SizeConfig.screenHeight,
        width: SizeConfig.screenWidth,
        color: ColorConstant.whiteBody,
        child: Padding(
          padding: const EdgeInsets.only(left: 10.0, right: 10.0, top: 10),
          child: Column(
            children: [
              Expanded(child: _tabsBodyAllBids()),
            ],
          ),
        ),
      ),
    );
  }

  ListView _tabsBodyAllBids() {
    return ListView.builder(
      itemCount: 3,
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.all(4.0),
          child: ContainerCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 16, top: 16, bottom: 5),
                  child: TextComponent(
                    text: "Working since July 19, 2004",
                    textStyle: FontStyles.inter(
                        color: ColorConstant.greyishBrownTwo,
                        fontSize: 13,
                        fontWeight: FontWeight.w700),
                    textAlign: TextAlign.left,
                  ),
                ),
                CustomStepperCard(
                  dateFrom: "Thursday, April 3, 2020 - 6:00 AM",
                  addressFrom: "Central Warehouse, Mauripur, Karachi",
                  dateTo: "Thursday, April 3, 2020 - 6:00 AM",
                  addressTo:
                      "Central Warehouse, Mauripur, Karachi Central Warehouse, Mauripur, Karachi",
                  trailingIcons: false,
                  childWidgets: Column(
                    children: [
                      Divider(
                        thickness: 0.9,
                      ),
                      Align(
                        alignment: Alignment.bottomRight,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: CustomContainerButtonComponent(
                            text: StringConstant.rateNow,
                            textColor: ColorConstant.white,
                            color: ColorConstant.blueGreen,
                            horizontal: 10,
                            onTap: ()=>Navigator.pushNamed(context, RouteConstants.rateNow),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
