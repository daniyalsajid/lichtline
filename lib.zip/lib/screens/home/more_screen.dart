import 'package:truckit/constants/strings/string_constants.dart';
import 'package:flutter/material.dart';

class MoreScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text(StringConstant.more),
    );
  }
}
