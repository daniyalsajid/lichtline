class ActionConstants {
  static const String navigateForward = "navigateForward";
}
