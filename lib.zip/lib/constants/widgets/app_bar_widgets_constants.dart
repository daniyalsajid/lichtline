// import 'package:truckit/components/app_bars/simple_app_bar_component.dart';
// import 'package:truckit/constants/colors/colors_constants.dart';
// import 'package:truckit/constants/styles/font_styles_constants.dart';
// import 'package:flutter/material.dart';

// class AppBarWidgetConstants {
//   static SimpleAppBarComponent appBarWithbackButton(
//           {@required String title, Color color = ColorConstant.bodyColor}) =>
//       SimpleAppBarComponent(
//         isBackButton: true,
//         color: color,
//         isTitle: true,
//         title: title,
//         titleStyle: FontStyles.abrilFatface(
//             color: ColorConstant.black,
//             fontSize: 17.0,
//             fontWeight: FontWeight.w500),
//       );
// }
