// import 'package:truckit/constants/colors/colors_constants.dart';
// import 'package:flutter/material.dart';

// class WidgetsDecorationConstant {
//   static BoxDecoration buttonGradientContainer(
//           {double radiusTopLeft: 20.0,
//           double radiusTopRight: 20.0,
//           double radiusBottomLeft: 20.0,
//           double radiusBottomRight: 20.0}) =>
//       BoxDecoration(
//         gradient: ColorConstant.btnLinearGradient,
//         borderRadius: BorderRadius.only(
//           topLeft: Radius.circular(radiusTopLeft),
//           topRight: Radius.circular(radiusTopRight),
//           bottomLeft: Radius.circular(radiusBottomLeft),
//           bottomRight: Radius.circular(radiusBottomRight),
//         ),
//       );
// }
