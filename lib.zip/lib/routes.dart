import 'package:truckit/screens/auth/login_screen.dart';
import 'package:truckit/screens/auth/otp_verification_screen.dart';
import 'package:truckit/screens/bid/payment_verification_screen.dart';
import 'package:truckit/screens/home/bottom_bar_screen.dart';
import 'package:truckit/screens/message/chat_screen.dart';
import 'package:truckit/screens/notification/notifcation_screen.dart';
import 'package:truckit/screens/on_boarding/on_boarding_screen.dart';
import 'package:truckit/screens/profile/profile_settings/profile_settings_screen.dart';
import 'package:flutter/material.dart';
import 'package:truckit/screens/profile/profile_settings/review/rate_now_screen.dart';
import 'package:truckit/screens/profile/profile_settings/review/review_screen.dart';
import 'package:truckit/screens/ride/current_ride_screen.dart';
import 'package:truckit/screens/ride/report_now_screen.dart';
import 'package:truckit/splash_screen.dart';
import 'constants/routes/routes_constants.dart';

onGenerateRoutes(RouteSettings settings) {
  switch (settings.name) {
    case RouteConstants.splashScreen:
      return MaterialPageRoute(
        builder: (_) => SplashScreen(),
      );
    case RouteConstants.login:
      return MaterialPageRoute(
        builder: (_) => LoginScreen(),
      );
    case RouteConstants.otpVerification:
      return MaterialPageRoute(
        builder: (_) => OTPVerificationScreen(),
      );
    case RouteConstants.bottomBarScreen:
      return MaterialPageRoute(
        builder: (_) => BottomBarScreen(),
      );
    case RouteConstants.chat:
      return MaterialPageRoute(
        builder: (_) => ChatScreen(),
      );
    case RouteConstants.notification:
      return MaterialPageRoute(
        builder: (_) => NotificationScreen(),
      );
    case RouteConstants.currentRideScreen:
      return MaterialPageRoute(
        builder: (_) => CurrentRideScreen(),
      );
    case RouteConstants.reportNow:
      return MaterialPageRoute(
        builder: (_) => ReportNowScreen(),
      );
    case RouteConstants.reviewScreen:
      return MaterialPageRoute(
        builder: (_) => ReviewScreen(),
      );
    case RouteConstants.rateNow:
      return MaterialPageRoute(
        builder: (_) => RateNowScreen(),
      );
    case RouteConstants.paymentVerification:
      return MaterialPageRoute(
        builder: (_) => PaymentVerificationScreen(),
      );
    default:
  }
}
