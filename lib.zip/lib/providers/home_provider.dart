import 'package:flutter/cupertino.dart';

class HomeProvider extends ChangeNotifier {
  
}
